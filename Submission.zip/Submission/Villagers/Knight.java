package Villagers;

import Territories.Territory;
import Weapons.Weapon;
import java.util.Random;

public class Knight extends Villager {

    private int attackPower;
    private Weapon weapon;

    public Knight(String name) {
        super(name, "Knight");
        Random rand = new Random();
        this.attackPower = rand.nextInt(11); // random attack power 0–10
        this.weapon = null;
    }

    // Attack = base attack power + weapon strength if equipped
    public int getAttackPower() {
        if (weapon != null) {
            return attackPower + weapon.getWeaponPower();
        } else {
            return attackPower;
        }
    }

    // Knight collects a weapon from the territory's weapon list
    public void collectWeapon(Territory territory) {
        if (this.weapon != null) {
            System.out.println(getName() + " already has a weapon and skips collecting");
            return;
        } 

        if (territory.getWeaponsList().isEmpty()) {
            System.out.println(getName() + " found no weapons to collect");
            return;
        }
        
        Weapon newWeapon = territory.getWeaponsList().remove(0);
        this.weapon = newWeapon;
        System.out.println(getName() + " collected: " + newWeapon);
    }

    // Getter for currently equipped weapon
    public Weapon getEquippedWeapon() {
        return weapon;
    }

    public void setEquippedWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
}
