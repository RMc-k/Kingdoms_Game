package Villagers;

import java.util.Random;

public class Farmer extends Villager{

    private int farmingSkill;

    public Farmer(String name) {
        super(name, "Farmer");
        Random rand = new Random();
        this.farmingSkill = rand.nextInt(11) + 1;
    }

    public int getFarmingSkill(){
        return farmingSkill;
    }
    
    public void improveSkill(int amount){
        farmingSkill += amount;
    }

}
