package Villagers;

public abstract class Villager {
    private String name;
    private String profession;
    private int health;
    
    // For repeatable gameplay, all unique values in child class' will be generated at random. 
    // Health preset to 100 for all new characters.
    public Villager(String name, String profession){
        this.name = name;
        this.profession = profession;
        this.health = 100;

    }

    public String getName() {
        return name;
    }

    public String getProfession() {
        return profession;
    }

    public int getHealth() {
        return health;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public void setHealth(int health) {
        this.health = Math.max(0, Math.min(health, 100)); //Prevents out of bounds health
    }
}


