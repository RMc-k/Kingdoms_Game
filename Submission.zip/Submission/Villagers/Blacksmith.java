package Villagers;

import Territories.Territory;
import Buildings.Building;
import Buildings.Forge;
import Weapons.Weapon;
import Weapons.WeaponType;
import java.util.Random;
import java.util.Scanner;

public class Blacksmith extends Villager {

    private int craftsmanship;

    public Blacksmith(String name) {
        super(name, "Blacksmith");
        Random rand = new Random();
        this.craftsmanship = rand.nextInt(11);
    }

    public int getCraftsmanship() {
        return craftsmanship;
    }

    public void upgradeDefences(Territory territory, Scanner sc){
        System.out.println("Blacksmith: " + getName() + " is ready to build!");
        System.out.println("1: Build Defences? (Building Defences costs 5 resources)");
        System.out.println("2: Double up Defences? (Doubling Building Defences costs 10 resources)");

        int choice = sc.nextInt();
        sc.nextLine();

        if (choice == 1 && territory.getResources() >= 5){
            territory.setResources(territory.getResources() - 5);
            territory.setTerritoryDefence(territory.getTerritoryDefence() + 2);
            System.out.println("Territory Defences increased + 2");
        } else if (choice == 2 && territory.getResources() >= 10){
            territory.setResources(territory.getResources() - 10);
            territory.setTerritoryDefence(territory.getTerritoryDefence() + 5);
            System.out.println("Territory Defences increased: + 5");
        } else {
            System.out.println("Not enough resources!");
        }
        System.out.println("Remaining resources: " + territory.getResources());
    }

    public void forgeWeapon(Territory territory, Scanner sc){
        Forge inForge = null;

        // Find the Forge the Blacksmith's in
        for(Building b: territory.getBuildingsList()){
            if (b instanceof Forge && b.getOccupantsList().contains(this)){
                inForge = (Forge) b;
                break;
            }
        }

        if (inForge == null){
            System.out.println(getName() + " must be in a Forge to forge weapons!");
            return;
        }

        // Confirmed Blacksmith is in forge - proceed
        System.out.println("Blacksmith: " + getName() + " is ready to forge a Weapon! You have: "  + territory.getResources() + " resources remaining!");
        System.out.println("Choose a weapon to forge (cost: 3 resources):");
        System.out.println("1: The Sword of Destiny (Damage: " + WeaponType.Sword.getBaseDamage() + ")");
        System.out.println("2: The Axe of Justice (Damage: " + WeaponType.Axe.getBaseDamage() + ")");
        System.out.println("3: The Devilish Dagger (Damage: " + WeaponType.Dagger.getBaseDamage() + ")");
        System.out.println("4: Apollos Bow (Damage: " + WeaponType.Bow.getBaseDamage() + ")");

        int choice = sc.nextInt();
        sc.nextLine();

        //Check the user has resources to forge
        if (territory.getResources() < 3){
            System.out.println("Not enough resources to forge a weapon!");
            return;
        }

        //Parent reference
        WeaponType type;
        switch(choice){
            case 1: type = WeaponType.Sword; break;
            case 2: type = WeaponType.Axe; break;
            case 3: type = WeaponType.Dagger; break;
            default: type = WeaponType.Bow; break;
        }
        // Deduction of resource + assignment to weaponsList
        territory.setResources(territory.getResources() - 3);
        Weapon newWeapon = new Weapon (type, type.getBaseDamage());
        territory.getWeaponsList().add(newWeapon);
        System.out.println("Forged weapon: " + newWeapon + " (is now available for Knights to collect)");
    }
}
