package Territories;

public class Kingdom extends Territory{

    // Kingdoms start with > defences but no wealth + prestige
    public Kingdom(String territoryName, int resources) {
        super("Kingdom", territoryName, resources, 0, 0, 10);
    }

    @Override
    public String getTerritoryType(){
        return super.getTerritoryType();
    }
}