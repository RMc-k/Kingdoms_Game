package Territories;

import java.util.List;
import java.util.ArrayList;
import Buildings.Building;
import Villagers.Villager;
import Weapons.Weapon;


public abstract class Territory{

    private String territoryType;
    private String territoryName;
    private int resources;
    private int wealth;
    private int prestige;
    protected int basePrestige;
    private int territoryDefence;

    private List<Building> buildingsList;
    private List<Villager> villagersList;
    private List<Weapon> weaponsList;


    public Territory(String territoryType, String territoryName, int resources, int wealth, int prestige, int territoryDefence){
        this.territoryType = territoryType;
        this.territoryName = territoryName;
        this.resources = resources;
        this.wealth = wealth;
        this.prestige = prestige;
        this.basePrestige = prestige;
        this.territoryDefence = territoryDefence;
        buildingsList = new ArrayList<>();
        villagersList = new ArrayList<>();
        weaponsList = new ArrayList<>();
    }

    public String getTerritoryType(){
        return territoryType;
    }

    public String getTerritoryName(){
        return territoryName;
    }

    public int getResources(){
        return resources;
    }

    public int getWealth(){
        return wealth;
    }

    public int getPrestige(){
        return prestige;
    }

    public int getBasePrestige(){
        return basePrestige;
    }

    public int getTerritoryDefence(){
        return territoryDefence;
    }

    public List<Building> getBuildingsList(){
        return buildingsList;
    }

    public List<Villager> getVillagersList(){
        return villagersList;
    }

    public List<Weapon> getWeaponsList(){
        return weaponsList;
    }

    public void setTerritoryType(String territoryType){
        this.territoryType = territoryType;
    }

    public void setTerritoryName(String territoryName){
        this.territoryName = territoryName;
    }

    public void setResources(int resources){
        this.resources = resources;
    }

    public void setWealth(int wealth){
        this.wealth = wealth;
    }

    public void setPrestige(int prestige){
        this.prestige = prestige;
    }

    public void setTerritoryDefence(int territoryDefence){
        this.territoryDefence = territoryDefence;
    }
}

