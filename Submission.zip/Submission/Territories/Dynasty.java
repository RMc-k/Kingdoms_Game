package Territories;

public class Dynasty extends Territory{

    public Dynasty(String territoryName, int prestige, int wealth) {
        super("Dynasty", territoryName, 0, wealth, prestige, 5);
    }

    @Override
    public String getTerritoryType(){
        return super.getTerritoryType();
    }
}