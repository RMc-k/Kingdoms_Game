package Buildings;

public class Barracks extends Building{

    public Barracks(){
        super("Barracks");
    }

    @Override
    public String toString(){
        return super.getBuildingType();
    }
}
