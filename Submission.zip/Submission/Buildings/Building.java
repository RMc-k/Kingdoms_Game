package Buildings;

import Villagers.Villager;
import java.util.ArrayList;
import java.util.List;

public abstract class Building {

    private String buildingType;
    private int buildingHealth;
    private List<Villager> occupants;
    private final int capacity;

    public Building(String buildingType){
        this.buildingType = buildingType;
        this.buildingHealth = 100;
        this.occupants = new ArrayList<>();
        this.capacity = 3; // max villager limit per building
    }

    public String getBuildingType(){
        return buildingType;
    }

    public int getBuildingHealth(){
        return buildingHealth;
    }

    public List<Villager> getOccupantsList(){
        return occupants;
    }

    public void setBuildingType(String buildingType){
        this.buildingType = buildingType;
    }

    public int getCapacity(){
        return capacity;
    }

    public boolean isFull(){
        return occupants.size() >= capacity;
    }
}