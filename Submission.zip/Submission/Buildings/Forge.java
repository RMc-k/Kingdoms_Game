package Buildings;

import java.util.List;
import java.util.ArrayList;
import Weapons.Weapon;


public class Forge extends Building{

    private List <Weapon> weapons; 

    public Forge(){
        super("Forge");
        weapons = new ArrayList<>();
    }

    public List<Weapon> getWeapons(){
        return weapons;
    }
    
    @Override 
    public String toString(){
        return super.getBuildingType();
    }
}
