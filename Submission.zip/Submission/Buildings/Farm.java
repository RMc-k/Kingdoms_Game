package Buildings;

import Villagers.Villager;
import Villagers.Farmer;
import Territories.Territory;

public class Farm extends Building{

    public Farm(){
        super("Farm");
    }

    public void generateResources(Territory territory){
        int total = 0;
        for (Villager v : getOccupantsList()){
            if ( v instanceof Farmer){
                Farmer f = (Farmer) v;
                total += f.getFarmingSkill();
            }
        }

        territory.setResources(territory.getResources() + total);
    }

    @Override
    public String toString(){
        return super.getBuildingType();
    }
}
