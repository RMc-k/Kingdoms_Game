package Weapons;

public class Weapon{

    private WeaponType type;
    private int weaponPower;

    public Weapon(WeaponType type, int weaponPower){
        this.type = type;
        this.weaponPower = weaponPower;
    }

    public WeaponType getType(){
        return type;
    }

    public int getWeaponPower(){
        return weaponPower;
    }

    @Override
    public String toString(){
        return type + " (Weapon power: " + weaponPower + ")";
    }
}