package Weapons;

public enum WeaponType {

    Sword(10),
    Axe(15),
    Dagger(5),
    Bow(8);

    private final int baseDamage;

    WeaponType(int baseDamage){
        this.baseDamage = baseDamage;
    }

    public int getBaseDamage(){
        return baseDamage;
    }
}
