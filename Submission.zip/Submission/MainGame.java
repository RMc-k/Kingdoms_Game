import java.util.Scanner;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import Territories.Territory;
import Territories.Kingdom;
import Territories.Dynasty;
import Buildings.Building;
import Buildings.Farm;
import Buildings.Barracks;
import Buildings.Forge;
import Villagers.Villager;
import Villagers.Knight;
import Villagers.Farmer;
import Villagers.Blacksmith;
import Weapons.Weapon;
import Weapons.WeaponType;


public class MainGame{
    public static void main(String[] args){
        // Initialize scanner
        Scanner sc = new Scanner (System.in);

        // Simple Scanner takes the user from Kingdom generation to character & buildings assignment
        System.out.println("==================================================");
        System.out.println("          Welcome to the Kingdoms Game!!          ");
        System.out.println("==================================================");


        System.out.println("Select your territory type: ");
        System.out.println("1: Kingdom");
        System.out.println("2: Dynasty");

        // Takes the next integer the user types as their selection
        int choice = sc.nextInt();
        sc.nextLine();

        System.out.println("Enter your territory name: ");
        // Allocates the string user types and moves to the next line
        String territoryName = sc.nextLine();

        // Parent reference
        Territory territory;

        // Scanner inputs seperated logically
        if (choice == 1){ 
            // getIntInRange only allows the user to insert an int within the given parameters
            int resources = getIntInRange(sc, "Enter starting resources (0-10) for your Kingdom \"" + territoryName + "\":", 0, 10);
            territory = new Kingdom(territoryName, resources);
        } else {
            int prestige = getIntInRange(sc, "Enter starting prestige (0-5) for your Dynasty \"" + territoryName + "\":", 0,5);
            int wealth = getIntInRange(sc, "Enter starting wealth (0-100) for your Dynasty \"" + territoryName + "\":", 0, 100);
            territory = new Dynasty(territoryName, prestige, wealth);
        }

        System.out.println("Territory created: " + territory.getTerritoryName() + ". Lets see the special statistics and features of your " + territory.getTerritoryType() + "!");
        printTerritoryStats(territory);

        // List to store all enemy territories our user can interact with
        List<Territory> enemies = new ArrayList<>();

        // Introducing enemy Territories for battles in game using randomness
        List <String> enemyPool = new ArrayList<>(Arrays.asList(
            "Kingdom: Roman Empire",
            "Kingdom: Valhalla",
            "Kingdom: Atlantis",
            "Kingdom: Avalon",
            "Kingdom: Kingdom of Rohan",
            "Dynasty: Padishah Empire",
            "Dynasty: Ottoman Dynasty",
            "Dynasty: Dynasty of Persia",
            "Dynasty: Covenant Empire",
            "Dynasty: Empire of the Rising Sun"
        ));

        Random rand = new Random(); 


        //Creating 3 enemies
        // for loop: Start at 0 at incruments of 1 and must be no more than 3 selections (0,1,2)
        for (int i = 0; i < 3; i++){
            int index = rand.nextInt(enemyPool.size()); // Random selection from 1 to the length of our enemyPool
            String chosen = enemyPool.remove(index); // Each enemy is uniquely named
            // Split used as substring method to create two 'parts'
            String[] parts = chosen.split(": ");
            //Seperators type & name used to differentiate between an enemy kingdom or dynasty
            String type = parts[0];
            String name = parts[1];

            // Enemy inherits Territory
            Territory enemy;
            if (type.equals("Kingdom")){
                enemy = new Kingdom(name, 5 + rand.nextInt(11)); //Resources starting from 5-15
                enemy.setWealth(10 + rand.nextInt(20)); //Ensures enemy kingdoms have starting wealth / loot for user during war
            } else {
                enemy = new Dynasty(name, rand.nextInt(6), 10 + rand.nextInt(91)); //Prestige 0-5, wealth 10-100
            }

            // Adding Knights to make battles functional
            int knightCount = 1 + rand.nextInt(3); // 1-3 Knights
            for (int k = 1; k <= knightCount; k++){
                Knight knight = new Knight ("Enemy Knight " + k);
                // Random allocation of weapons to enemy knights 
                if (rand.nextBoolean()){
                    // Weapon type issued to enemy knights
                    Weapon sword = new Weapon(WeaponType.Sword, 5 + rand.nextInt(6));
                    knight.setEquippedWeapon(sword);
                }
                // Add the knight to the enemies villagers list
                enemy.getVillagersList().add(knight);
            }
            enemies.add(enemy);
        }


        //User Feedback on new enemies
        System.out.println("Enemies have risen in your lands..");
        //Iterate through enemies 
        for (Territory e: enemies){
            System.out.println("*** " + e.getTerritoryName() + " (" + e.getTerritoryType() + ") ***");
        }


        System.out.println("==================================================");
        System.out.println("            Lets add some characters!!            ");
        System.out.println("==================================================");

        // bool for adding one or multiple villagers
        boolean addMoreVillagers = true; 

        // Create new buildings
        Farm farm = new Farm();
        Barracks barracks = new Barracks();
        Forge forge = new Forge();

        // Add buildings to the Territory
        territory.getBuildingsList().add(farm);
        territory.getBuildingsList().add(barracks);
        territory.getBuildingsList().add(forge);

        // Initiated while loop to allow > 1 villager/character generation
        while(addMoreVillagers){

            // currentVillagers used to give the user a view of how many villagers they can create before paying
            int currentVillagers = territory.getVillagersList().size();

            //Checks the cap, first 3 villagers are free, after that requires gameplay
            if (territory.getVillagersList().size() >= 3){
                System.out.println("3 Villagers is a perfect start! Recruiting more villagers now costs 5 wealth");
                if(territory.getWealth() < 5){
                    System.out.println("Not enough wealth to recruit another villager. Current wealth: " + territory.getWealth());
                    break; // Stops to the loop if the user cant afford villager 
                }
            } else {
                System.out.println("You can create up to " + (3 - currentVillagers) + " more free villagers");
            }

            System.out.println("Choose your character: ");
            System.out.println("1: Knight");
            System.out.println("2. Farmer");
            System.out.println("3. Blacksmith");
            //Gives the user an exit if they dont want to proceed with creating another villager
            if(territory.getVillagersList().size() >= 3){
                System.out.println("4: Stop adding villagers");
            }

            int villagerChoice = sc.nextInt();
            sc.nextLine();

            if (villagerChoice == 4 && territory.getVillagersList().size() >= 3){
                System.out.println("You chose to stop adding villagers");
                break;
            }

            String profession;
            if (villagerChoice == 1) profession = "Knight";
            else if (villagerChoice == 2) profession = "Farmer";
            else profession = "Blacksmith";

            System.out.println("What is the " + profession + "s name?");
            String name = sc.nextLine();

            //Deduct wealth if > 3 villagers created
            if (currentVillagers >= 3 && territory.getWealth() >= 5){
                territory.setWealth(territory.getWealth() - 5);
                System.out.println("Recruitment cost 5 wealth. Remaining wealth: " + territory.getWealth());
            } 
            
            // Adding villager to specified territory list & printing unique stats.
            Villager villager;
            if (villagerChoice == 1) villager = new Knight(name);
            else if (villagerChoice == 2) villager = new Farmer(name);
            else villager = new Blacksmith(name);

            territory.getVillagersList().add(villager);
            printVillagerStats(villager, territory);


            // Assigning Villagers to Buildings + compatibility
            boolean assigned = false;

            while(!assigned){
                System.out.println("Choose a new home for " + villager.getName());
                System.out.println("1: Farm");
                System.out.println("2. Barracks");
                System.out.println("3. Forge");

                int buildingChoice = sc.nextInt();
                sc.nextLine();
            
                //Parent reference & assignment
                Building chosenBuilding;
                if (buildingChoice == 1) chosenBuilding = farm;
                else if (buildingChoice == 2) chosenBuilding = barracks;
                else chosenBuilding = forge;

                //Check capacity
                if (chosenBuilding.isFull()){
                    System.out.println("This " + chosenBuilding.getClass().getSimpleName() + " is full (max " + chosenBuilding.getCapacity() + "). Build another to increase population");
                    continue;
                }

                // Checking to see if choice is appropriate for villagers unique skills.
                boolean compatible = (villager instanceof Farmer && buildingChoice == 1) || 
                                     (villager instanceof Knight && buildingChoice == 2) ||
                                     (villager instanceof Blacksmith && buildingChoice == 3);

                // Warning if farmer != farm etc
                if (!compatible) {
                    System.out.println("Warning: " + villager.getProfession() + "s usually go to their standard building. Continue anyway? (y/n)");
                    String response = sc.nextLine();
                    if (response.equalsIgnoreCase("y")) {
                        assigned = true; 
                    } else {
                        continue;
                    }
                } else {
                    assigned = true; // correct assignment
                }
                if (assigned) {
                    chosenBuilding.getOccupantsList().add(villager);
                    updatePrestigeFromBarracks(territory);
                }
            }  

        // Ask if the user wants to add another villager then print building assignments
        System.out.println("Do you want to add another villager? (y/n)");
        String response = sc.nextLine();
        if(response.equalsIgnoreCase("n")) addMoreVillagers = false;
        printBuildingAssignments(territory);
        }

        boolean continuePlaying = true;
        while (continuePlaying){
            // Run a full turn
            boolean endGameSelected = playTurn(territory, enemies, sc);

            if (endGameSelected){
                continuePlaying = false;
                break;
            }

            //Print updated stats
            printTerritoryStats(territory);

            // Ask the user if they want to play their next turn
            System.out.println("Do you want to play the next turn? (y/n)");
            String turnResponse = sc.nextLine();
            if (turnResponse.equalsIgnoreCase("n")) continuePlaying = false;
        }
        sc.close();
    }
        
    // Helper ensures input is within allowed limits
    public static int getIntInRange(Scanner sc, String prompt, int min, int max){
        int value;
        do{
            System.out.println(prompt);
            value = sc.nextInt();
            if(value < min || value > max){
                System.out.println("Please enter a value between " + min + " and " + max);
            }
        } while (value < min || value > max);
        return value;
    }

    // Helper gives the user a view of their character and their unique traits
    public static void printVillagerStats(Villager v, Territory territory){
        System.out.println("Name: " + v.getName());
        System.out.println("Profession: " + v.getProfession());
        System.out.println("Health: " + v.getHealth());
        if(v instanceof Knight k){
            System.out.println("Attack Power: " + k.getAttackPower());
            Weapon weapon = k.getEquippedWeapon();
            if (weapon != null){
                System.out.println("Weapon: " + weapon);
            } else {
                System.out.println("No Weapon equipped");
            }
        } else if(v instanceof Farmer f){
            System.out.println("Farming Skill: " + f.getFarmingSkill());
        } else if(v instanceof Blacksmith b){
            System.out.println("Craftsmanship: " + b.getCraftsmanship());
        }
    }

    // Helper gives the user a view of the key stats of their Kingdom/Dynasty
    public static void printTerritoryStats(Territory t){
        System.out.println("==================================================");
        System.out.println("Territory Name: " + t.getTerritoryName());
        System.out.println("Type: " + t.getTerritoryType());
        System.out.println("Population: " + t.getVillagersList().size());
        System.out.println("Buildings: " + t.getBuildingsList().size());
        System.out.println("Resources: " + t.getResources());
        System.out.println("Wealth: " + t.getWealth());
        System.out.println("Prestige: " + t.getPrestige());
        System.out.println("Defences: " + t.getTerritoryDefence());
        System.out.println("==================================================");
    }

    // Helper gives the user a view of buildings and assigned villagers
    public static void printBuildingAssignments(Territory t){
        System.out.println("==================================================");
        System.out.println("Buildings and Assigned Villagers in: " + t.getTerritoryName());
        System.out.println("==================================================");
        if (t.getBuildingsList().isEmpty()){
            System.out.println("No buildings to see here!");
        } else {
            for (Building b : t.getBuildingsList()){
                System.out.println(b.getClass().getSimpleName());
                if (b.getOccupantsList().isEmpty()){
                    System.out.println(" - No Villagers assigned!");
                } else {
                    for (Villager v : b.getOccupantsList()){
                         System.out.println(" - " + v.getProfession() + ": " + v.getName());
                    }
                }
            }
        }
        System.out.println("==================================================");   
    }

    //Generates resources from Farms in Territory
    public static void generateResources(Territory territory) {
        for (Building b : territory.getBuildingsList()){
            if (b instanceof Farm){
                ((Farm) b).generateResources(territory); 
            }
        }
        System.out.println("Total Resources: " + territory.getResources());
    }

    // Updates prestige based on Knights in Barracks: more Knights > better Prestige
    public static void updatePrestigeFromBarracks(Territory territory){
        int knightCount = 0;
        for (Building b: territory.getBuildingsList()){
            if (b instanceof Barracks){
                for (Villager v: b.getOccupantsList()){
                    if (v instanceof Knight){
                        knightCount ++;
                    }
                }
            }
        }
        // Ensures "Congratulations prestige increased" message only pops up when a Knight is added
        int newPrestige = territory.getBasePrestige() + knightCount;

        if(newPrestige > territory.getPrestige()){
            System.out.println("Congratulations! Prestige has increased: " + newPrestige);
        }
        territory.setPrestige(newPrestige);

    }

    // Helper that calls at the end of each turn so the enemy can grow
    public static void growEnemies(List<Territory> enemies, Random rand){
        for (Territory enemy: enemies){
            // Gain resources after each turn
            int resourceGain = 1 + rand.nextInt(3); // 1-3 resources gained
            enemy.setResources(enemy.getResources() + resourceGain);

            // Small chance new Knight is spawned 
            if (rand.nextDouble() < 0.33){ // 1/3 chance
                Knight newKnight = new Knight("Enemy Knight " + (enemy.getVillagersList().size() + 1));

                if (rand.nextBoolean()){
                    newKnight.setEquippedWeapon(new Weapon(WeaponType.Sword, 5 + rand.nextInt(6)));
                }

                enemy.getVillagersList().add(newKnight);
                System.out.println(newKnight + " added");
                // System.out.println used to validate above and below (wanted to keep enemy growth unknown to the user)
            }
            // 50/50 chance the enemies defences increase
            if (rand.nextBoolean()){
                int defenceGain = 1 + rand.nextInt(3); // 1-3 T-defence gain
                enemy.setTerritoryDefence(enemy.getTerritoryDefence() + defenceGain);
                // Commented print function out, used for testing
                System.out.println(enemy.getTerritoryName() + " strengthened its defences by " + defenceGain);
            }
        }
    }

    public static void goToWar(Territory player, List<Territory> enemies, Scanner sc) {
        // Make sure there are enemies to attack
        if(enemies.isEmpty()){
            System.out.println("No enemies to attack");
            return;
        }

        System.out.println("Enemies available to attack:");
        System.out.println("0: Fall back! Return to battle another day");
        for (int i = 0; i < enemies.size(); i++){
            System.out.println((i + 1) + ": " + enemies.get(i).getTerritoryName() + " (" + enemies.get(i).getTerritoryType() + ")");
        }


    int enemyChoice = - 1; //Initialize bool with invalid value
    // While ensures the user has an 'out' and ensures correct entry
    while (true){
        System.out.println("Select your enemy target:");
        enemyChoice = sc.nextInt() - 1; // converts entry to index
        sc.nextLine();

        if (enemyChoice == -1){ //User chose 0
            System.out.println("You decided to retreat, end of turn");
            return;
        }

        if (enemyChoice >= 0 && enemyChoice < enemies.size()){
            break;
        } else {
            System.out.println("Invalid choice. Please try again.");
        }
    }
    // Identify the chosen enemy territory + assigning as target
    Territory target = enemies.get(enemyChoice);
    System.out.println("Attacking: " + target.getTerritoryName() + "....");

    // Calculate total attack power of Knights 
    int totalAttack = 0;
    for (Villager v: player.getVillagersList()){
        if (v instanceof Knight k){
            // getAttackPower already combines weapon strength if equipped
            totalAttack += k.getAttackPower();
        }
    }
    System.out.println("Total attack power: " + totalAttack);

    //Apply attack to enemy territory defences first
    int remainingDefences = target.getTerritoryDefence() - totalAttack;
    if (remainingDefences > 0){
        // Not enough attackPower to breach defences
        target.setTerritoryDefence(remainingDefences);
        System.out.println("Enemy defences withstood your offences! Remaining defences: " + remainingDefences);
        // End turn
        return;
    } else {
        // Defences breached
        target.setTerritoryDefence(0);
        System.out.println("Enemy defences have been breached! KNIGHTS ATTACK!");
    }

    // Track Knights lost in battle
    List<Knight> deadPlayerKnights = new ArrayList<>();
    List<Knight> deadEnemyKnights = new ArrayList<>();

    // Knights engage in batlle
    for (Villager enemy: target.getVillagersList()){
        if (enemy instanceof Knight k){
            int enemyHealth = k.getHealth(); //All villagers have 100 health to start
            int damage = totalAttack; // Attack goes to a single Knight
            enemyHealth -= damage;
            if (enemyHealth <= 0){
                System.out.println("Enemy Knight " + k.getName() + " has fallen!");
                k.setHealth(0);
                // Add to dead knights list
                deadEnemyKnights.add(k);
            } else {
                k.setHealth(enemyHealth);
                System.out.println("Enemy knight " + k.getName() + " survives with " + enemyHealth + "health!");

            }
        }
    }

    // Deduct wealth from target
    int damageToWealth = Math.min(totalAttack, target.getWealth());
    target.setWealth(target.getWealth() - damageToWealth);
    System.out.println("We damaged our enemies wealth by " + damageToWealth + "."); //Wanted to keep the enemies remining Wealth a mystery to the user

    // Reward the users territory with the wealth (if attack successful)
    player.setWealth(player.getWealth() + damageToWealth);
    System.out.println("Your army are eating good tonight!! " + damageToWealth + " wealth taken and brought back home!");

    //Enemy knights retaliate
    for (Villager playerKnight : player.getVillagersList()){
        if (playerKnight instanceof Knight k){
            int playerHealth = k.getHealth();
            int enemyAttack = 0;

            // Sum attack power of all  enemy knights
            for (Villager enemy: target.getVillagersList()){
                if(enemy instanceof Knight ek){
                    enemyAttack += ek.getAttackPower();
                }
            }
            // Apply attack to users Knight 
            playerHealth -= enemyAttack;

            if (playerHealth <= 0){
                System.out.println("Your knight: " + k.getName() + " has fallen to enemy retaliation");
                k.setHealth(0);
                deadPlayerKnights.add(k); // Add fallen knights to deadPlayerKnights
            } else {
                k.setHealth(playerHealth);
                System.out.println("Your knight: " + k.getName() + " survives the enemies retaliation with " + k.getHealth() + " health remaining!");

            }
        }
    }

    // Battle Summary
    System.out.println("===== The Great Battle of " + player.getTerritoryName() + " & " + target.getTerritoryName() + " has now Ended =====");
    System.out.println("===== Enemy Knights defeated: " + deadEnemyKnights.size() + " =====");
    System.out.println("===== Your Knights lost: " + deadPlayerKnights.size() + " =====");
    System.out.println("===== " + target.getTerritoryName() + "'s remaining defences: " + target.getTerritoryDefence() + " =====");
    System.out.println("===== Your current wealth: " + player.getWealth() + " =====");

    // Remove dead player knights from their respective lists
    player.getVillagersList().removeAll(deadPlayerKnights);
    target.getVillagersList().removeAll(deadEnemyKnights);

    // End of Turn
    System.out.println("End of turn. Prepare for your next move.");
    }

    
    public static void enemyAttacksTerritory(List<Territory> enemies, Territory territory, Random rand) {
        if (enemies.isEmpty() || rand.nextDouble() >= 0.2){ //20% chance an enemy will attack after each turn
            return; // No attck this turn

        }

        Territory attacker = enemies.get(rand.nextInt(enemies.size())); // Random enemy
        System.out.println(attacker.getTerritoryName() + " is attacking your territory!! "); 

        //Calculate enemy attack power
        int enemyAttackPower = 0;
        for (Villager v: attacker.getVillagersList()){
            if (v instanceof Knight k){
                    enemyAttackPower += k.getAttackPower();
            }
        }
        System.out.println(attacker.getTerritoryName() + " attacks with a total power: " + enemyAttackPower); 

        //Attack defences first
        int remainingDefences = territory.getTerritoryDefence() - enemyAttackPower;
        if (remainingDefences > 0){
            territory.setTerritoryDefence(remainingDefences);
            System.out.println("Your defences held strong!! Remaining defences: " + remainingDefences);
        } else {
            territory.setTerritoryDefence(0);
            System.out.println("Your defences have been breached! Knights get ready to defend!");

            // Fallen Knights list
            List<Knight> deadPlayerKnights = new ArrayList<>();
            List<Knight> deadEnemyKnights = new ArrayList<>();

            // Enemy attacks
            for (Villager v: territory.getVillagersList()){
                if (v instanceof Knight k){
                    int playerHealth = k.getHealth() - enemyAttackPower; // Applied to each knight 

                    if (playerHealth <= 0){
                        System.out.println("Your Knight: " + k.getName() + " has fallen during the battle");
                        k.setHealth(0);
                        deadPlayerKnights.add(k);
                    } else {
                        k.setHealth(playerHealth);
                        System.out.println("Your Knight " + k.getName() + " survives with " + playerHealth + " health remaining.");
                    }
                }
            }

            // Damage enemy knights (retaliation)
            int totalPlayerAttack = 0;
            for (Villager v: attacker.getVillagersList()){
                if (v instanceof Knight k){
                    int weaponPower = 0;
                    if (k.getEquippedWeapon() != null){
                        weaponPower = k.getEquippedWeapon().getWeaponPower();
                    }
                    totalPlayerAttack += k.getAttackPower() + weaponPower;
                }
            }

            for (Villager v: attacker.getVillagersList()){
                if (v instanceof Knight ek){
                    int enemyHealth = ek.getHealth();
                    int damage = totalPlayerAttack;
                    enemyHealth -= damage;

                    if (enemyHealth <= 0){
                        System.out.println("Enemy Knight " + ek.getName() + " has been slain in retaliation");
                        ek.setHealth(0);
                        deadEnemyKnights.add(ek);
                    } else {
                        ek.setHealth(enemyHealth);
                        System.out.println("Enemy Knight " + ek.getName() + " survives with " + enemyHealth + " health remaining!");
                    }
                }
            }
            // Enemy steals wealth from player 
            int stolenWealth = Math.min(enemyAttackPower, territory.getWealth());
            territory.setWealth(territory.getWealth() - stolenWealth);
            attacker.setWealth(attacker.getWealth() + stolenWealth);
            System.out.println(attacker.getTerritoryName() + " has stolen " + stolenWealth + " wealth from " + territory.getTerritoryName());

            // Battle Summary
            System.out.println("===== The Great Battle of " + territory.getTerritoryName() + " & " + attacker.getTerritoryName() + " has now Ended =====");
            System.out.println("===== Enemy Knights defeated: " + deadEnemyKnights.size() + " =====");
            System.out.println("===== Your Knights lost: " + deadPlayerKnights.size() + " =====");
            System.out.println("===== " + territory.getTerritoryName() + "'s remaining defences: " + territory.getTerritoryDefence() + " =====");
            System.out.println("===== Your current wealth: " + territory.getWealth() + " =====");

            //Remove dead knights
            territory.getVillagersList().removeAll(deadPlayerKnights);
            attacker.getVillagersList().removeAll(deadEnemyKnights);
        }
    }

    // Helper used to boost Knights health using food generated from farmers farmingSkill
    public static void feedKnights(Territory territory){
        int totalFood = 0;

        for (Villager v: territory.getVillagersList()){
            if (v instanceof Farmer f){
                totalFood += f.getFarmingSkill();
            }
        }

        if (totalFood == 0){
            System.out.println("No food produced this turn. Your Knights remain hungry!");
            return;
        }
        System.out.println("Your farmers produced " + totalFood + " food portions this turn.");

        // Heal Knight using food 
        for (Villager v: territory.getVillagersList()){
            if (v instanceof Knight k){
                int newHealth = Math.min(100, k.getHealth() + totalFood * 3); // 3 * food goes to health. health limited to 100
                k.setHealth(newHealth);
                System.out.println("Knight " + k.getName() + " healed to " + newHealth + " health!");
            }
        }
    }

    // Building a turn-based approach //Returns a boolean to allow the user to exit the game
    public static boolean playTurn(Territory territory, List <Territory> enemies, Scanner sc){
        System.out.println("==================================================");
        System.out.println("==================== NEW TURN ====================");
        System.out.println("==================================================");

        //Declaring random object for use in enemyCounterAttack helper
        Random rand = new Random();

        // User can make multiple actions in this turn
        boolean endTurn = false;
        while (!endTurn){

            // First the farmer needs to generate resources from the farm
            generateResources(territory);

            //while loop allows the user to make 5 actions before the end of their turn
            int actions = 0;
            while (actions < 5){
                System.out.println("Actions left this turn: " + (5 - actions));
            
                // Ask what the user wants to do with their turn
                System.out.println("What would you like to do with this turn?");
                System.out.println("1: Forge a Weapon");
                System.out.println("2: Build defences");
                System.out.println("3: Make a Trade");
                System.out.println("4: Construct a new Building");
                System.out.println("5: Create a new Villager");   
                System.out.println("6: Heal your Knights");
                System.out.println("7: Go to War!");
                System.out.println("8: End  turn");
                System.out.println("9: End game (progress won't be saved)");

                int turnChoice = sc.nextInt();
                sc.nextLine();

                // First choice: The Blacksmith forge weapons
                if (turnChoice == 1){
                    boolean hasBlacksmith = false;

                    for (Building b: territory.getBuildingsList()){
                        if (b instanceof Forge){
                            for (Villager v : b.getOccupantsList()){
                                if (v instanceof Blacksmith blacksmith){
                                    hasBlacksmith = true;
                                    System.out.println(blacksmith.getName() + " is forging a weapon..");
                                    blacksmith.forgeWeapon(territory, sc);
                                }
                            }
                        }
                    }

                    if (!hasBlacksmith){
                        // A Blacksmith has to be in a forge to build weapons
                        System.out.println("No Blacksmiths to forge, recruit a Blacksmith");
                        continue;
                    }

                    // Knights collect weapons automatically
                    for (Building b: territory.getBuildingsList()){
                        if (b instanceof Barracks){
                            for (Villager v: b.getOccupantsList()){
                                if (v instanceof Knight k){
                                    // Only collects a weapon if the knight doesnt already have one
                                    k.collectWeapon(territory);
                                }
                            }
                        }
                    }
                }
                  
                // Second choice: Blacksmith upgrades territory defences
                else if (turnChoice == 2){
                    boolean foundBlacksmith = false;
                    for (Building b: territory.getBuildingsList()){
                        for (Villager v : b.getOccupantsList()){
                            if (v instanceof Blacksmith blacksmith){
                                blacksmith.upgradeDefences(territory, sc);
                                foundBlacksmith = true;
                            }
                        }
                    }
                    if (!foundBlacksmith){
                        System.out.println("You have no Blacksmiths to build defences");
                    }
                }
                // Third choice: Trade resources forr wealth
                else if (turnChoice == 3){
                    boolean tradeDone = false; // Gives the user an exit once the trade's done/cancelled
                    while (!tradeDone){
                        System.out.println("Choose trade type: (You have " + territory.getResources() + " Resources & " + territory.getWealth() + " Wealth)");
                        System.out.println("0: Cancel the trade");
                        System.out.println("1: Trade Resources for Wealth (2 Resources = 1 Wealth) ");
                        System.out.println("2: Trade Wealth for Resources (1 Wealth = 2 Resources) ");

                        int tradeType = sc.nextInt();
                        sc.nextLine();

                        if (tradeType == 0){
                            System.out.println("Trade Cancelled. Returning to turn menu");
                            tradeDone = true;
                        }
                        else if (tradeType == 1){
                            System.out.println("How many Resources would you like to trade?");
                            int toTrade = sc.nextInt();
                            sc.nextLine();

                            if (toTrade > territory.getResources()){
                                System.out.println("You don't have enough Resources! Try again..");
                            } else if (toTrade < 2){
                                System.out.println("You need at least 2 Resources to trade. Try again..");
                            } else {
                                int wealthGained = toTrade / 2;
                                territory.setResources(territory.getResources() - toTrade);
                                territory.setWealth(territory.getWealth() + wealthGained);
                                System.out.println("Trade Successful! Traded " + toTrade + " Resources for " + wealthGained + " Wealth.");
                                tradeDone = true; // Successful trade, exit loop 
                            }
                        }
                        else if (tradeType == 2){
                            System.out.println("How much Wealth would you like to trade?");
                            int toTrade = sc.nextInt();
                            sc.nextLine();

                            if (toTrade > territory.getWealth()){
                                System.out.println("You don't have enough Wealth! Try again..");
                            } else if (toTrade < 1){
                                System.out.println("You need at least 1 Wealth to trade. Try again..");
                            } else {
                                int resourceGained = toTrade * 2;
                                territory.setWealth(territory.getWealth() - toTrade);
                                territory.setResources(territory.getResources() + resourceGained);
                                System.out.println("Trade Successful! Traded " + toTrade + " Wealth for " + resourceGained + " Resources.");
                                tradeDone = true;
                            }
                        }
                        else {
                            System.out.println("Invalid trade option. Try again..");
                        }
                    }   
                }
                //Use wealth to buy/create a new Building
                else if (turnChoice == 4){
                    System.out.println("Choose a building to construct (Buildings cost 5 wealth)");
                    System.out.println("1: Farm");
                    System.out.println("2: Barracks");
                    System.out.println("3: Forge");
                    System.out.println("4: Go back to actions menu");

                    int buildChoice = sc.nextInt();
                    sc.nextLine();

                    // Gives user an option to return to actions menu
                    if (buildChoice == 4){
                        System.out.println("Returning to actions menu..");
                        continue;
                    }

                    //Check if theres enough wealth before proceeding
                    if(territory.getWealth() < 5){
                        System.out.println("You don't have enough wealth! (5 needed to build)");
                    } else {
                        // If there's wealth proceed to create desired building
                        Building newBuilding = null;

                        if (buildChoice == 1) newBuilding = new Farm();
                        else if (buildChoice == 2) newBuilding = new Barracks();
                        else if (buildChoice == 3) newBuilding = new Forge();

                        // if newly assigned newBuilding is now occupied, add it to the buildings list, deduct the wealth, amd print result
                        if (newBuilding != null){
                            territory.getBuildingsList().add(newBuilding);
                            territory.setWealth(territory.getWealth() - 5);
                            System.out.println("Constructed a new " + newBuilding.getClass().getSimpleName() + "!");
                        }
                    }
                }
                // Option 5: Create a new Villager
                else if (turnChoice == 5){
                    if (territory.getWealth() < 5){
                        System.out.println("Not enough Wealth to add a new villager! (5 needed)");
                        continue;
                    }
                    System.out.println("Choose the type of villager to add:");
                    System.out.println("1: Farmer");
                    System.out.println("2: Blacksmith");
                    System.out.println("3: Knight");
                    System.out.println("0: Cancel");

                    int villagerChoice = sc.nextInt();
                    sc.nextLine();

                    if (villagerChoice == 0){
                        System.out.println("Cancelled adding a new villager!");
                        continue;
                    }

                    System.out.println("Enter a name for your new villager:");
                    String villagerName = sc.nextLine();

                    Villager newVillager;
                    if (villagerChoice == 1) newVillager = new Farmer(villagerName);
                    else if (villagerChoice == 2) newVillager = new Blacksmith(villagerName);
                    else if (villagerChoice == 3) newVillager = new Knight(villagerName);
                    else {
                        System.out.println("Invalid villager type selected. Turn skipped.");
                        continue;
                    }

                    boolean assigned = false;
                    while (!assigned){
                        System.out.println("Choose a new home for " + newVillager.getName());
                        System.out.println("1: Farm");
                        System.out.println("2: Barracks");
                        System.out.println("3: Forge");
                        System.out.println("0: Cancel assignment");

                        int buildingChoice = sc.nextInt();
                        sc.nextLine();

                        if (buildingChoice == 0){
                            System.out.println("Assignment cancelled. " + newVillager.getName() + " was not assigned to a building.");
                            break;
                        }

                        Building chosenBuilding;
                        // Fetch the buildings from the territory list
                        Farm farm = null;
                        Barracks barracks = null;
                        Forge forge = null;

                        for (Building b : territory.getBuildingsList()) {
                            if (b instanceof Farm) farm = (Farm) b;
                            else if (b instanceof Barracks) barracks = (Barracks) b;
                            else if (b instanceof Forge) forge = (Forge) b;
                        }

                        if (buildingChoice == 1) chosenBuilding = farm;
                        if (buildingChoice == 2) chosenBuilding = barracks;
                        else chosenBuilding = forge;

                        if (chosenBuilding == null || chosenBuilding.isFull()){
                            System.out.println("This building is full or hasn't been built. Please choose another or build another one.");
                            continue;
                        }

                        boolean compatible = (newVillager instanceof Farmer && buildingChoice == 1) || (newVillager instanceof Knight && buildingChoice == 2) || (newVillager instanceof Blacksmith && buildingChoice == 3);

                        if (!compatible){
                            System.out.println("Warning: " + newVillager.getProfession() + "s usually go to their standard building. Continue anyway? (y/n)");
                            String response = sc.nextLine();
                            if (response.equalsIgnoreCase("y")) assigned = true;
                            else continue; 
                        } else {
                            assigned = true;
                        }

                        // Assign Villager
                        chosenBuilding.getOccupantsList().add(newVillager);
                        territory.getVillagersList().add(newVillager);
                        territory.setWealth(territory.getWealth() - 5);
                        System.out.println(newVillager.getName() + " has been assigned to " + chosenBuilding);
                        printVillagerStats(newVillager, territory);
                    }
                }

                //Healing Knight using feedKnights helper
                else if (turnChoice == 6){
                    feedKnights(territory);
                }

                // Option 6: Go to war
                else if(turnChoice == 7){
                    goToWar(territory, enemies, sc);
                    endTurn = true;
                    break;
                }

                // Ending turn
                else if (turnChoice == 8){
                    System.out.println("Ending turn..");
                    endTurn = true;
                    //exit actions immediately
                    break;
                }

                else if (turnChoice == 9){
                    System.out.println("Are you sure? All progress will be lost! (y/n)");
                    String confirm = sc.nextLine();
                    if (confirm.equalsIgnoreCase("y")){
                        System.out.println("Ending game. Thanks for playing!");
                        return true;
                    } else {
                        System.out.println("Game continued.");
                        return false;
                    }
                }

                //Incrument 1 action for each action taken unless cancelled 
                actions++;
            }
            // Update prestige once per turn
            updatePrestigeFromBarracks(territory);

            // Print Stats at end of turn
            printTerritoryStats(territory);

            // Possible enemy attack at end of turn
            enemyAttacksTerritory(enemies, territory, rand);
                
        }
        // Turn complete, continue game 
        return false;
    }
}